// 21102121_MANSUR JULIANTO_IF09R 

package Guided;

abstract class BangunDatar {
    abstract double hitungKeliling();
    abstract double hitungLuas();
}
